import React, {Component} from 'react';
import Drawer from './src/navigators/drawer-navigator';
export default class App extends React.Component {

  
  render() {
    return (
      <Drawer/>
    );
  }
}

